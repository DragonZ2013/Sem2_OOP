#include <Controller.h>

Controller::Controller(Repository &other_repo) : repo(other_repo)
{
    //repo=other_repo;
}

void Controller::Add_To_Repo(string str)
{
    repo.Add_Fruit(str);
}