#include <iostream>
#include "UI.h"

int main()
{
	Repository rep;
	rep.Add_Fruit("mango");
	rep.Add_Fruit("mango");
	rep.Add_Fruit("apple");
	rep.Add_Fruit("melon");
	rep.Remove_Fruit("apple");
	rep.Print_Arr();
	Controller cont(rep);
	//rep.Add_Fruit("test");
	cont.Add_To_Repo("test2");
	return 0;
}