#include "UI.h"

UI::UI(Repository repo_other)
{
    repo=repo_other;
    //to-do use with adress
}

void UI::Print_FilterByName(string substring)
{//to-do use repo for filter
    vector<Fruits> temp_arr=repo.Get_Arr();
    int temp_size=repo.Get_Size();
    for(int i=0;i<temp_size;i++)
    {
        if (temp_arr[i].get_name().find(substring) != std::string::npos)
            temp_arr[i].Print_Fruit();
    }
}

void UI::Print_FilterByQuantity(int LessThan)
{//to-do use repo for filter
    vector<Fruits> temp_arr=repo.Get_Arr();
    int temp_size=repo.Get_Size();
    for(int i=0;i<temp_size;i++)
    {
        if (temp_arr[i].get_quantity() < LessThan)
            temp_arr[i].Print_Fruit();
    }
}

