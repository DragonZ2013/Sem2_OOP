#include "Controller.h"

class UI
{
private:
    Controller cont;
public:

    UI(Controller cont_other);

    void Print_FilterByName();//console input string

    void Print_FilterByQuantity(int LessThan);//console input int


};