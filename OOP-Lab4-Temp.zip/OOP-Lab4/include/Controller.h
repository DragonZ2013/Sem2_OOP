#include <Repository.h>

class Controller
{
private:
    Repository repo;

    
public:

    Controller(Repository &other_repo);

    void Add_To_Repo(string str);

    vector<Fruits> FilterByQuantity(int LessThan);



};