#pragma once
#include <string>
#include <ctime>
#include <exception>
#include <iostream>
#include <algorithm>
using namespace std;
class Fruits
{
private:
    //int id;
    string name;
    string origin;
    string exp_date;//yyyy-mm-dd
    int quantity;
    double price;
public:

    Fruits(string name,string origin,string exp_date,double price);

    string get_name();

    void set_name(string new_name);

    string get_origin();

    void set_origin(string new_origin);

    //getter/setter for exp_date

    int get_quantity();

    void set_quantity(int new_quantity);

    void add_elements(int count);

    void remove_elements(int count);

    double get_price();

    void set_price(double new_price);

    void Print_Fruit();

    ~Fruits();
};