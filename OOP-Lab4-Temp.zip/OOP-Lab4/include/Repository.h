#pragma once
#include "Fruits.h"
//#include "Controller.h"
#include <vector>

class Repository
{
private:
    vector<Fruits> arr;
    int size;
public:

    Repository();

    int Get_Size();

    vector<Fruits> Get_Arr();

    int Pos_Fruit(string name);

    int Add_Fruit(string name);

    int Remove_Fruit(string name);

    void Edit_Fruit_Origin(string name,string new_origin);

    void Print_Arr();

    //Controller point() const;

};