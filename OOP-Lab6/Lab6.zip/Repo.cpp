#include "Repo.h"
#include "Error.h"
#include <algorithm>
namespace Repository{
        
    Repo::Repo(){
        id_new_elem=0;
    }

    const int Repo::GetSize() const
    {
        return this->elems.size();
    }

    int Repo::pos_by_id(const int find_id) const
    {
        for(unsigned int i=0;i<elems.size();i++)
        {
            if(elems[i].Get_id()==find_id)
                return i;
        }
        return -1;
    }

    const Domain::Car &Repo::search_by_id(const int find_id) const
    {
        if(pos_by_id(find_id)==-1)
            throw CustomError("Car not in list");
        return this->elems[pos_by_id(find_id)];
    }

    vector<Domain::Car> Repo::Get_array() const {
        return this->elems;
    }

    void Repo::add(Domain::Car & c)
    {
        c.Set_id(id_new_elem);
        id_new_elem++;
        this->elems.push_back(c);
    }
    
    void Repo::remove(const int find_id)
    {
        if(pos_by_id(find_id)==-1)
            throw CustomError("Car not in list");
        elems.erase(elems.begin()+pos_by_id(find_id));
    }

    void Repo::update(const Domain::Car &new_car)
    {
        int pos=new_car.Get_id();
        if(pos_by_id(pos)==-1)
            throw CustomError("Car not in list");
        if(new_car.Get_model()!="")
            elems[pos].Set_model(new_car.Get_model());
        if(new_car.Get_mark()!="")
            elems[pos].Set_mark(new_car.Get_mark());
        if(new_car.Get_year()!=-1)
            elems[pos].Set_year(new_car.Get_year());
        if(new_car.Get_km()!=-1)
            elems[pos].Set_km(new_car.Get_km());
        if(new_car.Get_price()!=-1)
            elems[pos].Set_price(new_car.Get_price());
        if(new_car.Get_performance()!=-1)
            elems[pos].Set_performance(new_car.Get_performance());
        if(new_car.Get_fuel()!="")
            elems[pos].Set_fuel(new_car.Get_fuel());
        

    }
}